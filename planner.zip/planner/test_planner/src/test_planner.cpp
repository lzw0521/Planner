
#include <test_planner/test_planner.h>
#include <pluginlib/class_list_macros.h>
#include <tf2/convert.h>
#include <tf2/utils.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <ros/ros.h>
#include <nav_msgs/Path.h>
//register this planner as a BaseGlobalPlanner plugin
PLUGINLIB_EXPORT_CLASS(test_planner::TestPlanner, nav_core::BaseGlobalPlanner)

namespace test_planner {

  TestPlanner::TestPlanner()
  : costmap_ros_(NULL), initialized_(false){}

  TestPlanner::TestPlanner(std::string name, costmap_2d::Costmap2DROS* costmap_ros)
  : costmap_ros_(NULL), initialized_(false){
    initialize(name, costmap_ros);
  }

  void TestPlanner::initialize(std::string name, costmap_2d::Costmap2DROS* costmap_ros){
    if(!initialized_){
      costmap_ros_ = costmap_ros;
      costmap_ = costmap_ros_->getCostmap();
      
      ros::NodeHandle private_nh("~/" + name);

      ros::NodeHandle nk;

      my_pub = nk.advertise<nav_msgs::Path>("my_plan", 1);

      private_nh.param("step_size", step_size_, costmap_->getResolution());
      private_nh.param("min_dist_from_robot", min_dist_from_robot_, 0.10);
      world_model_ = new base_local_planner::CostmapModel(*costmap_);

      initialized_ = true;
    }
    else
      ROS_WARN("This planner has already been initialized... doing nothing");
  }

  //we need to take the footprint of the robot into account when we calculate cost to obstacles
  double TestPlanner::footprintCost(double x_i, double y_i, double theta_i){
    if(!initialized_){
      ROS_ERROR("The planner has not been initialized, please call initialize() to use the planner");
      return -1.0;
    }

    std::vector<geometry_msgs::Point> footprint = costmap_ros_->getRobotFootprint();
    //if we have no footprint... do nothing
    if(footprint.size() < 3)
      return -1.0;

    //check if the footprint is legal
    double footprint_cost = world_model_->footprintCost(x_i, y_i, theta_i, footprint);
    return footprint_cost;
  }


  bool TestPlanner::makePlan(const geometry_msgs::PoseStamped& start,
      const geometry_msgs::PoseStamped& goal, std::vector<geometry_msgs::PoseStamped>& plan){

    if(!initialized_){
      ROS_ERROR("The planner has not been initialized, please call initialize() to use the planner");
      return false;
    }

    ROS_DEBUG("Got a start: %.2f, %.2f, and a goal: %.2f, %.2f", start.pose.position.x, start.pose.position.y, goal.pose.position.x, goal.pose.position.y);

    plan.clear();
    costmap_ = costmap_ros_->getCostmap();

    if(goal.header.frame_id != costmap_ros_->getGlobalFrameID()){
      ROS_ERROR("This planner as configured will only accept goals in the %s frame, but a goal was sent in the %s frame.",
          costmap_ros_->getGlobalFrameID().c_str(), goal.header.frame_id.c_str());
      return false;
    }

    const double start_yaw = tf2::getYaw(start.pose.orientation);
    const double goal_yaw = tf2::getYaw(goal.pose.orientation);

    //we want to step back along the vector created by the robot's position and the goal pose until we find a legal cell
    double goal_x = goal.pose.position.x;
    double goal_y = goal.pose.position.y;
    double start_x = start.pose.position.x;
    double start_y = start.pose.position.y;

    double diff_x = goal_x - start_x;
    double diff_y = goal_y - start_y;
    double diff_yaw = angles::normalize_angle(goal_yaw-start_yaw);

    double target_x = goal_x;
    double target_y = goal_y;
    double target_yaw = goal_yaw;

    bool done = false;
    double scale = 1.0;
    double dScale = 0.01;

    while(!done)
    {
      if(scale < 0)
      {
        target_x = start_x;
        target_y = start_y;
        target_yaw = start_yaw;
        ROS_WARN("The carrot planner could not find a valid plan for this goal");
        break;
      }
      //target_x = start_x + scale * diff_x;
      target_x = start_x;
      target_y = start_y;

      target_yaw = angles::normalize_angle(start_yaw + scale * diff_yaw);

      double footprint_cost = footprintCost(target_x, target_y, target_yaw);
      if(footprint_cost >= 0)
      {
          done = true;
      }
      scale -=dScale;
    }

    geometry_msgs::PoseStamped new_goal[600];
    for (int i=1;i<=5;i++)
    {
      //geometry_msgs::PoseStamped new_goal[500];
 
      if (i%2==0){
            for(int k=1;k<=100;k++)
            {
              new_goal[(i-1)*100+k-1] = goal;
              tf2::Quaternion goal_quat;
              goal_quat.setRPY(0, 0, target_yaw);
              new_goal[(i-1)*100+k-1].pose.position.x = start_x+diff_x-(k-1)*diff_x/99;
              new_goal[(i-1)*100+k-1].pose.position.y = start_y+0.2*(i-1)*diff_y;
              new_goal[(i-1)*100+k-1].pose.orientation.x = goal_quat.x();
              new_goal[(i-1)*100+k-1].pose.orientation.y = goal_quat.y();
              new_goal[(i-1)*100+k-1].pose.orientation.z = goal_quat.z();
              new_goal[(i-1)*100+k-1].pose.orientation.w = goal_quat.w();
              plan.push_back(new_goal[(i-1)*100+k-1]);
              
            }
            for(int k=1;k<=20;k++)
            {
              new_goal[(i-1)*120+100+k-1] = goal;
              tf2::Quaternion goal_quat;
              goal_quat.setRPY(0, 0, target_yaw);
              new_goal[(i-1)*120+100+k-1].pose.position.x = start_x;
              new_goal[(i-1)*120+100+k-1].pose.position.y = start_y+0.2*(i-1)*diff_y+k*(0.2*diff_y/21);
              new_goal[(i-1)*120+100+k-1].pose.orientation.x = goal_quat.x();
              new_goal[(i-1)*120+100+k-1].pose.orientation.y = goal_quat.y();
              new_goal[(i-1)*120+100+k-1].pose.orientation.z = goal_quat.z();
              new_goal[(i-1)*120+100+k-1].pose.orientation.w = goal_quat.w();
              plan.push_back(new_goal[(i-1)*120+100+k-1]);

            }
      }
      else{
            for(int k=1;k<=100;k++)
            {
              new_goal[(i-1)*100+k-1] = goal;
              tf2::Quaternion goal_quat;
              goal_quat.setRPY(0, 0, target_yaw);
              new_goal[(i-1)*100+k-1].pose.position.x = start_x+(k-1)*diff_x/99;
              new_goal[(i-1)*100+k-1].pose.position.y = start_y+0.2*(i-1)*diff_y;
              new_goal[(i-1)*100+k-1].pose.orientation.x = goal_quat.x();
              new_goal[(i-1)*100+k-1].pose.orientation.y = goal_quat.y();
              new_goal[(i-1)*100+k-1].pose.orientation.z = goal_quat.z();
              new_goal[(i-1)*100+k-1].pose.orientation.w = goal_quat.w();
              plan.push_back(new_goal[(i-1)*100+k-1]);
              
            }
            for(int k=1;k<=20;k++)
            {
              new_goal[(i-1)*120+100+k-1] = goal;
              tf2::Quaternion goal_quat;
              goal_quat.setRPY(0, 0, target_yaw);
              new_goal[(i-1)*120+100+k-1].pose.position.x = start_x+diff_x;
              new_goal[(i-1)*120+100+k-1].pose.position.y = start_y+0.2*(i-1)*diff_y+k*(0.2*diff_y/21);
              new_goal[(i-1)*120+100+k-1].pose.orientation.x = goal_quat.x();
              new_goal[(i-1)*120+100+k-1].pose.orientation.y = goal_quat.y();
              new_goal[(i-1)*120+100+k-1].pose.orientation.z = goal_quat.z();
              new_goal[(i-1)*120+100+k-1].pose.orientation.w = goal_quat.w();
              plan.push_back(new_goal[(i-1)*120+100+k-1]);

            }
      }

    }

    geometry_msgs::PoseStamped terminal = goal;
    tf2::Quaternion goal_quat;
    goal_quat.setRPY(0, 0, target_yaw);
    terminal.pose.position.x = target_x+diff_x;
    terminal.pose.position.y = target_y+diff_y;

    terminal.pose.orientation.x = goal_quat.x();
    terminal.pose.orientation.y = goal_quat.y();
    terminal.pose.orientation.z = goal_quat.z();
    terminal.pose.orientation.w = goal_quat.w();

    plan.push_back(terminal);
    
    nav_msgs::Path my_path;
    my_path.poses.resize(plan.size());
    my_path.header.frame_id = plan[0].header.frame_id;
    my_path.header.stamp = ros::Time::now();

    for (unsigned int i = 0; i < plan.size(); i++) {
      my_path.poses[i] = plan[i];
    }
    my_pub.publish(my_path);  

    return (done);
  }

};
